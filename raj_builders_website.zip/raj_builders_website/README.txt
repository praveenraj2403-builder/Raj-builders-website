RAJ BUILDERS — free one-page website

Files:
- index.html: complete responsive website. Open it in a browser to preview.

Already included:
- Puducherry location
- Phone/WhatsApp: +91 85267 74406
- Residential, commercial, architectural design, construction, renovation and interior services
- Responsive mobile layout and basic SEO metadata

Before publishing:
1. Replace the temporary RB text mark with your exact official RAJ BUILDERS logo image.
2. Add real completed-project photos in the Projects section.
3. Add your business email and any exact office address if you want them displayed.

Free publishing:
- Create a GitHub account and a public repository named raj-builders-website.
- Upload index.html to the repository root.
- In repository Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
- GitHub Pages will provide a public website address after deployment.

This package is a ready-to-preview website, not yet a live public URL. A free custom .com domain is not included.
